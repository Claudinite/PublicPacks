# Growth — dedup local packs against the canon (per repo)

Reconcile this repo's **local packs** against the shared **canon** it consumes (Claudinite, vendored read-only), pruning local items — a pack's prose line, or a whole local check —
the canon now covers. It lands the run's prunes through a single PR against the repo's default branch.
Often there's nothing to prune, and that's fine. The run's
**Context** is **binding scope — not a hint**: do not re-decide or widen it.

> This task only prunes local packs against the canon; lifting local items up into the canon is the central
> promote task's job (canon-side).

## Conventions used in this doc

- **Default branch.** `main` stands for **this repository's default branch** — substitute whatever the repo uses.
- **GitHub access is MCP-native.** Updating the tracking issue and opening the PR go through the session's
  **GitHub MCP tools** (`mcp__github__*`). The unattended run carries no `gh` CLI, and its `GITHUB_TOKEN` holds
  a proxy placeholder a presence test passes on and the API refuses — so never reach for `gh`/`curl`, and never
  read that variable as evidence of one; and never clone another repo, which the shell's git can
  still reach — that boundary is the session's granted scope, not a missing capability.
- **The mounted canon.** The exact canon revision this repo currently consumes — compare against *that*, not a
  live fetch. It is what `.claudinite/shared/` holds at the mount's stamp (a promotion is visible here only
  once the update has brought the mount to include it). Prune only against what the repo actually mounts.
- **The dispatch's Context narrows the *yardstick*, never the local surface.** When the Context names
  newly-changed canon packs ("Re-check local items against these newly-changed canon packs: …"), **those packs
  are this run's entire yardstick**: every prune must cite a line or rule id from one of *them*, and you never
  widen the comparison to the rest of the mounted canon. What is *not* narrowed is the local side — **every**
  local item is in play against those packs, whatever it is about. (Local pack names are unrelated to canon
  pack names, so there is nothing to match up.) A dispatch with **no** Context block carries no such bound: the
  precondition emits the list only when the mounted canon moved, and its other arm — the repo's own local packs
  changed — deliberately emits none, so that run compares the fresh local items against the whole mounted canon.
- **The repo's local packs.** The set identified in [this pack's README](../../README.md#identifying-a-projects-capture-surface-its-local-packs) —
  everything under `.claudinite/local/packs/`. That's the corpus this task prunes within; the
  read-only mounted canon elsewhere under
  `.claudinite/` is never a prune target, only the yardstick you prune *against*.

## Start by reading the canon window diff

**Code-work already ran** — [worker.mjs](worker.mjs), the deterministic first phase of this task — and wrote
what the mounted canon **added** in this window into the tracking issue's body: per declared pack, the added
prose lines file by file, and the ids of any checks the window introduced. Your dispatch names that issue.
**Read it before opening a single local pack.**

That brief is the run's *starting point*, not a second bound: the Context's pack list is still what a prune
may cite, so a local item covered by an older line in one of those packs is a legitimate prune when you can
quote that line. What the brief buys you is attention spent where the *new* coverage is, instead of re-reading
a corpus whose lines mostly predate this run. It is complete except where it says otherwise — a file whose
diff has no text patch, and a per-file line cap, are both stated in place with the remainder counted; go
read those files directly.

A window in which no declared canon pack moved says so, and that run compares the repo's fresh local items
against the mounted canon as a whole — the same as a dispatch with no Context block.

The [skill](../../skills/growth-dedup/SKILL.md) owns what to do with the additions: which are candidates,
which prune nothing, and why a removed canon line is the reverse signal.

## The method lives in the skill

What to prune, strip, or rephrase; the keep-test (an item that says *more* than the canon stays; one that
only says it in repo-specific names goes); how a canon **check** covers an item more strongly than prose;
and the shrink-only discipline — all of that is owned by the
[**growth-dedup** skill](../../skills/growth-dedup/SKILL.md). Follow it; don't re-derive it here. This
worker only frames the unattended run around it.

## Discipline

- **Only remove a local item you can show the mounted canon genuinely covers — quote the canon line (or the
  covering check's rule id).** When unsure, leave it; a wrongful prune deletes a real local lesson.
- **Open a single PR against `main`** from the branch your item names (`Target-branch:`) — one PR for the
  whole run's prunes, not one per item — never a direct push, and never a branch of your own.
  **Title the commit and the PR
  `Claudinite growth: dedup local packs`** — the `growth-write-scope` check keys on that title to certify the
  run pruned only the repo's local packs. Then **deliver it as your instructions say to deliver a pull request** — that procedure, never this file, owns
  whether and how the PR lands. What holds the prune bar is the quote-the-canon-line discipline above, the
  `dedup-prune-integrity` and `growth-write-scope` checks, and CI — never a reviewer's second look, which a
  wrongful prune is easy to wave through anyway. **Put the issue reference in the commit message** —
  `Refs #<n>` for this task's tracking issue (below), in the commit itself, not only the PR body. The repo's
  `basics` `task-lifecycle` check gates a PR on its commits referencing an issue, so a prune commit that cites
  none reds the repo's CI and blocks the merge.
- If an edit touches something a test reads, run the repo's offline test suite and keep it green before pushing.

## The brief, and the record

Code-work has already posted **this window's canon diff** as a comment on your own work item — the issue you
are reading. That comment is the brief this run starts from. **It is a required input**: a work item carrying
no such comment is a failed run, not a lighter one, so park it (`task:status:needs-human-action`) naming what is missing rather
than re-deriving the window yourself.

The prune's own commit and PR body are the record — there is no changelog file and no standing issue. Name
in the PR body what each prune removed and the canon line that now covers it, so the claim behind it is
reviewable where the diff is.

## Nothing downstream catches a wrong prune

Proving the mounted canon genuinely covers a local item before pruning it — and telling "the canon now owns
this" from "the canon states this too generally, keep the local cut" — is a **judgment call**. The PR carrying a prune can land with no reviewer downstream to catch
what the run got wrong: a real lesson pruned on a claim the canon does not actually make is gone.

## What this task must never do

- **Never edit the read-only canon** — it only prunes the repo's *local packs* against it, and the
  `growth-write-scope` check reds a run that touches anything outside them.
- **Never land a prune outside a PR** — every prune rides the run's single PR, delivered by
  your instructions' pull-request delivery; a direct push to `main` is never in scope.
- **Never prune a local item without quoting the mounted-canon line (or covering check rule id) that covers
  it** — when unsure, leave it.
- **Never widen the dispatch's Context.** If it named the changed canon packs, a prune citing coverage from
  any *other* canon pack is out of scope for this run — leave the item; the cycle that moves that pack will
  reach it.
- **Never prune a local item that makes a stronger point about a narrower case** than the canon — that isn't
  redundancy. (A local item that only restates the canon in repo-specific names *is* prunable once the canon
  covers the point.)
- **Never let a dedup edit grow an entry or re-import canon prose** — every action removes portable text;
  the skill owns the strip discipline, and the `dedup-prune-integrity` check (this pack) is the backstop
  that reds the session when a dedup-labeled commit grows a local-pack prose file or restates a canon rule.
