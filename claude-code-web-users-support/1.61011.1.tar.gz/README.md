# claude-code-web-users-support pack

What a project can offer the people working on it **from the web** — a Claude Code web session runs
for a signed-in person in a managed container, and a terminal session does neither, so this is where
the capabilities that depend on knowing *who* is here — or on the managed container they get —
live. Today that is two: the pack each person brings with them, which the engine copies into
the repo at session start from a configured store repo wherever this pack is declared; and
[`environment-setup-command.sh`](environment-setup-command.sh), the generic body a project pastes
into its web environment's **Setup script** field so the image already holds the engine the repo
pins, and SessionStart downloads nothing. The setup script starts in the checkout's parent
directory, so the body looks for the checkout holding `.claudinite/launch` and runs
`sh .claudinite/launch env install` there, and it never fails. The body is the same for every
project, and it is the same line `cn init` and the move quote in their HANDOVER block, so the
issue asking for the paste carries it whether or not the repo declares this pack.

Declared, and seeded by `--init`. The pack holds an **address**, not the content: `config.repo` (and
an optional `config.path`, default `preferences`) name the store that holds one `<login>/` directory
per person, named for their GitHub login in lower case.

## Who the person is

The harness names a web session's person by email only, so the engine's session-start step reads
the GitHub login back from `GET /user` with the session's own token, `GH_TOKEN` and then
`GITHUB_TOKEN`. GitHub compares logins case-insensitively and directory names don't, so the store
holds the login in lower case and the step lowercases what the API returns. The token names
whoever it was minted for: an environment that puts a shared or bot token in either variable
makes every person in it that account.

The session-start context carries one line naming the login used and the directory copied, or
why nothing was.

## The pack a person brings

`<path>/<login>/` in the store is an ordinary pack directory - `RULES.md`, optional `pack.json`,
`skills/<name>/SKILL.md`, `declared-checks.json`, `provenance/`. At session start the engine
copies its Markdown and JSON into `.claudinite/temp/packs/current_user/`, the session pack root,
where the same loader that reads the canon and the repo's own packs picks it up: its rules ride
the memory channel through the rules index, its skills are mounted, its declared checks run. So a
person is not limited to stating preferences - anything a pack carries as data, they can carry.
The step also writes `.claudinite/temp/.gitignore`, so what it copies never shows up as a change
to commit, whatever the repo's own `.gitignore` says.

The copy runs only in an **attended** session: a routine fired under a person's account carries
their identity but not their presence, and the harness's attended flag is what the step reads. Every
miss - unattended, no identity, no configured store, no directory, a clone that fails, a pack past
the file or byte budget - leaves the directory holding nothing but a placeholder, and the line
says which before the session proceeds on default interaction behaviour. Reading is local-first:
when this repo *is* the store, the working copy wins over the default branch, so an edit in
progress is what the session sees. Otherwise the store is reached by a shallow, blob-filtered,
sparse `git clone` of that person's directory. `cn session user-pack` runs the same step by hand.

Being the store also constrains the tree: the directory name is the whole address, so each one is
one person's GitHub login in lower case, which the `preferences-store-file-names` check
([`checks/checks.go`](checks/checks.go)) audits.

**The store is as trusted as this repository.** A person's pack is what every session it is
copied into reads and runs - rules, skills, declared checks - so write access to a person's
directory is the power to steer their sessions.

## Protecting each person's directory

The store's `.github/CODEOWNERS` carries a block generated from its directories
([`store_codeowners.mjs`](store_codeowners.mjs)), so each person can know that nobody but them or
the store's admin changed their pack:

```
/<path>/                 @<admin>              a new directory needs the admin's approval
/<path>/<login>/         @<login> @<admin>     one line per person
/.github/CODEOWNERS      @<admin>
```

The admin is the store repository's owning account; an organization-owned store is not
supported. The admin is listed beside each person because GitHub never counts a pull request's
author as a code owner's approval, so a person's edit of their own pack needs the admin to
approve it. Regenerate the block in the change that adds or renames a directory:

```
node .claudinite/shared/packs/claude-code-web-users-support/write_store_codeowners.mjs
```

The file only names owners. Enforcement is a setting only a person can turn on: a ruleset on the
store's default branch, targeting it, that requires a pull request and review from Code Owners,
with the admin role on its bypass list.

What a person's pack carries is **personal, not project conventions**: conventions belong to the
packs that own each subject and load as prose, while these travel with a person across every project
they work in, and two people on one project can want different things.

## Rules (`RULES.md`)

| Rule | Severity | Reason | Enforcement |
|---|---|---|---|
| Changing a person's rules | medium | complexity | prose: <100 words |
| A person's first personal pack | high | correctness | prose: <50 words + check (`preferences-store-file-names`) |
| A person wanting more than rules | medium | complexity | prose: <100 words |
| A web session's missing toolchain | medium | complexity | prose: <50 words |

## Checks

The first four are advisory: a personal pack is a nice-to-have, and nothing here may block a session.
A directory missing its CODEOWNERS line falls to the admin's `/<path>/` line, so that drift fails
safe. `preferences-nothing-to-run` blocks a personal pack's `tasks/` directory and a manifest's `env` key: nothing runs either from a personal pack, so they only read as work that happens.

| Check | Severity | Reason | Enforcement |
|---|---|---|---|
| `preferences-store-configured` | medium | complexity | check: advisory |
| `preferences-store-file-names` | high | correctness | check: advisory |
| `preferences-store-codeowners` | high | correctness | check: advisory |
| `preferences-provenance` | low | complexity | check: advisory |
| `preferences-nothing-to-run` | medium | correctness | check: blocking |
